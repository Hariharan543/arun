import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {MatrimoniRegister} from './classes/matrimoni-register'
import {RouterModule,Routes} from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import {HttpModule} from '@angular/http';
import {HttpClientModule} from '@angular/common/http';
import { AppComponent } from './app.component';
import { MatrimoniRegisterComponent } from './components/matrimoni-register/matrimoni-register.component';
import { FormsModule } from '@angular/forms';
import { MatrimoniLoginComponent } from './components/matrimoni-login/matrimoni-login.component';
import { MatrimoniHomeComponent } from './components/matrimoni-home/matrimoni-home.component';
import { SearchUserComponent } from './components/search-user/search-user.component';
import { MatrimoniEditComponent } from './components/matrimoni-edit/matrimoni-edit.component';


const appRoutes:Routes =[

  {path:'',redirectTo: '/log',pathMatch:'full'},

  {path:'log',component:MatrimoniLoginComponent},
  {path:'op',component:MatrimoniRegisterComponent},
  {path:'hom',component:MatrimoniHomeComponent},
  {path:'ed',component:MatrimoniEditComponent},
  {path:'ser',component:SearchUserComponent}
]


@NgModule({
  declarations: [
    AppComponent,
    MatrimoniRegisterComponent,
    MatrimoniLoginComponent,
    MatrimoniHomeComponent,
    SearchUserComponent,
    MatrimoniEditComponent
    ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(appRoutes),
  ],
  providers: [MatrimoniRegister],
  bootstrap: [AppComponent]
})
export class AppModule { }



