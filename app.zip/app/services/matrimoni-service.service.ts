import { Injectable } from '@angular/core';
import {Http,Headers,RequestOptions,Response} from '@angular/http';
import {MatrimoniRegister} from '../classes/matrimoni-register';
import "rxjs/add/operator/map";
import "rxjs/add/operator/catch";
import "rxjs/observable/throw";
import {Search} from 'src/app/classes/search';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class MatrimoniServiceService {
    
 baseurl:string = "http://localhost:3050/index";
 headers = new Headers({'Content-Type' :'application/json'});
 options = new RequestOptions({headers:this.headers});
 
 private search = new Search();

 private register = new MatrimoniRegister();

  constructor(private http:Http) { }
  getRegisterDetails(register:MatrimoniRegister){
 
    return this.http.post(this.baseurl+"/getRegister",JSON.stringify(register),this.options).map((response:Response)=>response.json()).catch(this.error);
  }
 
 saveRegisterDetails(matrimoniRegister:MatrimoniRegister){
   alert(matrimoniRegister.userid);
   return this.http.post(this.baseurl+"/saveRegister",JSON.stringify(matrimoniRegister),this.options).map((response:Response)=>response.json()).catch(this.error);
 }

 getSearchDetails(){
  return this.http.get(this.baseurl+"/search/"+this.search.fromage+"/"+this.search.toage+"/"+this.search.caste+"/"+this.search.religion+"/"+this.search.maritalstatus,this.options).map((response:Response)=>response.json()).catch(this.error);

}

updateDetails(matrimoniRegister:MatrimoniRegister){
  alert(matrimoniRegister.userid);
  return this.http.put(this.baseurl+"/updateRegister",JSON.stringify(matrimoniRegister),this.options).map((response:Response)=>response.json()).catch(this.error);
}

deleteDetails(matrimoniRegister:MatrimoniRegister){
  alert(matrimoniRegister.userid);
 return this.http.delete(this.baseurl+"/deleteRegister/"+matrimoniRegister.userid,this.options).map((response:Response)=>response.json()).catch(this.error);
}

 error(error:Response)
 {
   return Observable.throw(error || 'server error' ) ;
 }

setter(register:MatrimoniRegister){
 this.register=register;
}

getter(){
  return this.register;
}
}
