import { TestBed } from '@angular/core/testing';

import { MatrimoniServiceService } from './matrimoni-service.service';

describe('MatrimoniServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MatrimoniServiceService = TestBed.get(MatrimoniServiceService);
    expect(service).toBeTruthy();
  });
});
