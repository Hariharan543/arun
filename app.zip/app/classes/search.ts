export class Search {
    fromage:number;
    toage:number;
    caste:string;
    religion:string;
    maritalstatus:string;
}
