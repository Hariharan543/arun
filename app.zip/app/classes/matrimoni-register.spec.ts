import { MatrimoniRegister } from './matrimoni-register';

describe('MatrimoniRegister', () => {
  it('should create an instance', () => {
    expect(new MatrimoniRegister()).toBeTruthy();
  });
});
