export class MatrimoniRegister {

    userid:string;
    password:string;
    mobileno:string;
    emailid:string;

}
