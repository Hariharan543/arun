import { Component, OnInit } from '@angular/core';
import { MatrimoniServiceService } from 'src/app/services/matrimoni-service.service';
import { MatrimoniRegister } from 'src/app/classes/matrimoni-register';
import { Router } from '@angular/router';

@Component({
  selector: 'app-matrimoni-edit',
  templateUrl: './matrimoni-edit.component.html',
  styleUrls: ['./matrimoni-edit.component.css']
})
export class MatrimoniEditComponent implements OnInit {

  constructor(private matrimoniService:MatrimoniServiceService,private router:Router) { }

  private register = new MatrimoniRegister();
  ngOnInit() {
  this.register= this.matrimoniService.getter();
  }

  save(){
         this.matrimoniService.updateDetails(this.register).subscribe((data)=>
         {
           console.log(data);
         }
         );
         this.router.navigate(['/hom']);
  }
delete(){
  this.matrimoniService.deleteDetails(this.register).subscribe((data)=>
  {
    console.log(data);
  },(error) => {
    console.log(error);
  });
}
}
