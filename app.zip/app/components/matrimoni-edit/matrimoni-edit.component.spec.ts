import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MatrimoniEditComponent } from './matrimoni-edit.component';

describe('MatrimoniEditComponent', () => {
  let component: MatrimoniEditComponent;
  let fixture: ComponentFixture<MatrimoniEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MatrimoniEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MatrimoniEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
