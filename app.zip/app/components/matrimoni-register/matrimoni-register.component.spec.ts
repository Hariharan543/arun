import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MatrimoniRegisterComponent } from './matrimoni-register.component';

describe('MatrimoniRegisterComponent', () => {
  let component: MatrimoniRegisterComponent;
  let fixture: ComponentFixture<MatrimoniRegisterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MatrimoniRegisterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MatrimoniRegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
