import { Component, OnInit } from '@angular/core';
import {MatrimoniServiceService} from 'src/app/services/matrimoni-service.service';
import {MatrimoniRegister} from 'src/app/classes/matrimoni-register';
import { Router } from '@angular/router';
@Component({
  selector: 'app-matrimoni-register',
  templateUrl: './matrimoni-register.component.html',
  styleUrls: ['./matrimoni-register.component.css']
})
export class MatrimoniRegisterComponent implements OnInit {

  private register=new MatrimoniRegister();

  constructor(private matrimoniService:MatrimoniServiceService,private router:Router) { }

  ngOnInit() {
       // this.matrimoniService.getRegisterDetails().subscribe((data)=>{
         // console.log(data);
          //this.register=data;
      //   } );
      
  }
  saveRegisterDetails(){

    this.matrimoniService.saveRegisterDetails(this.register).subscribe((data)=>{
      console.log(data);
   
    },(error)=>{
    console.log(error);
    });
  
this.router.navigate(['/hom']);

    
    
  }

}
