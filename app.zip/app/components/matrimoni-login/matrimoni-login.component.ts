import { Component, OnInit } from '@angular/core';
import {MatrimoniServiceService} from 'src/app/services/matrimoni-service.service';
import {MatrimoniRegister} from 'src/app/classes/matrimoni-register';
import {Router} from '@angular/router';
import { isEmptyExpression } from '@angular/compiler';


@Component({
  selector: 'app-matrimoni-login',
  templateUrl: './matrimoni-login.component.html',
  styleUrls: ['./matrimoni-login.component.css']
})
export class MatrimoniLoginComponent implements OnInit {


  private register = new MatrimoniRegister();
  private srr:Array<any>;
  constructor(private matrimoniService:MatrimoniServiceService,private router:Router) { }

 
  ngOnInit() {

    // this.matrimoniService.getRegisterDetails().subscribe((data)=>{
    //   this.register=data;
    //   console.log(this.register);
    // },(error)=>{
    //   console.log(error);
    //   alert("invalid details");
    // });
    
  } 

  loginForm(a,b){
    this.register.userid=a;
    this.register.password=b;

    this.matrimoniService.getRegisterDetails(this.register).subscribe((data)=>{
      console.log(data);
      this.srr=data;
      this.matrimoniService.setter(data);
      if(this.srr.length>0)
      {
        this.router.navigate(['/hom']);
      }
      else{
        alert("Invalid Credentials");
      }
    },(error)=>{
        console.log(error);
    });  
  }  
}