import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MatrimoniLoginComponent } from './matrimoni-login.component';

describe('MatrimoniLoginComponent', () => {
  let component: MatrimoniLoginComponent;
  let fixture: ComponentFixture<MatrimoniLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MatrimoniLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MatrimoniLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
