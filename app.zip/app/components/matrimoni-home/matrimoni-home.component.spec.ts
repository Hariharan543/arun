import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MatrimoniHomeComponent } from './matrimoni-home.component';

describe('MatrimoniHomeComponent', () => {
  let component: MatrimoniHomeComponent;
  let fixture: ComponentFixture<MatrimoniHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MatrimoniHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MatrimoniHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
