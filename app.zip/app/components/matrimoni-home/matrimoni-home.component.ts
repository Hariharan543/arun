import { Component, OnInit } from '@angular/core';
import { MatrimoniServiceService } from 'src/app/services/matrimoni-service.service';
import { MatrimoniRegister } from 'src/app/classes/matrimoni-register';
import { Router } from '@angular/router';

@Component({
  selector: 'app-matrimoni-home',
  templateUrl: './matrimoni-home.component.html',
  styleUrls: ['./matrimoni-home.component.css']
})
export class MatrimoniHomeComponent implements OnInit {

  constructor(private matrimoniService:MatrimoniServiceService ,private router:Router) { }

  private register = new MatrimoniRegister();
  private register1:MatrimoniRegister[];
  ngOnInit() {
      this.register=this.matrimoniService.getter();
  }
 

  edit(r:MatrimoniRegister){
    this.matrimoniService.setter(r);
    this.router.navigate(['/ed']);
    
  }

  delete(user:MatrimoniRegister){
     this.matrimoniService.deleteDetails(user).subscribe((data)=>
     {
       this.register1.splice(this.register1.indexOf(user),1);
       console.log(data);
     },(error)=>{
       console.log(error);
     }
     );
  }
}